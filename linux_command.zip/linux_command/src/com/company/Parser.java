package com.company;

import java.util.ArrayList;
import java.util.Arrays;

public class Parser {
    String cmd = "";
    String [] args = new String[2];
    String RedirectingResult = ""; // file path
    String operator = "";
    boolean isValid = false;
    int index = 0;

    public Parser() {
        this.args[0] = "";
        this.args[1] = "";
    }
    public boolean parse(String order) {
        System.out.println("order length: " + order.length());
         ArrayList<String> commands = new ArrayList(Arrays.asList ("cd", " ls", "cp", "cat", "more", "mkdir", "rmdir", "mv", "rm", "args", "date", "help", "pwd", "clear", "exit"));
         ArrayList<String> orderInput = new ArrayList();
         String temp = "";

         // each index in the array (orderInput) include a single word form the order
         for (int i = 0; i < order.length(); i++){
             if (order.charAt(i) != ' ' && i < order.length()-1)
                 temp += order.charAt(i);
             else if(i == order.length()-1){
                 temp += order.charAt(i);
                 orderInput.add(temp);
             }
             else{
                 orderInput.add(temp);
                 temp = "";
             }
         }

         /*
         for (int i = 0; i < orderInput.size(); i++)
             System.out.println("order input of " + i + " = " + orderInput.get(i));
        */
         for (int i = 0; i < orderInput.size(); i++) {
             if (i == 0 && orderInput.contains(orderInput.get(i))) {
                 this.cmd = orderInput.get(i);

                 isValid = true;
             } else {

                 if (i == 0) {

                     return false;
                 }
                 else if (orderInput.get(i).equals(">>")  ) {
                    this.operator = ">>";
                     this.RedirectingResult = orderInput.get(i + 1); // file path
                 }
                 else if (orderInput.get(i).equals(">")){
                     this.operator = ">";
                     this.RedirectingResult = orderInput.get(i + 1); // file path
                 }
                 else {
                    System.out.println("index = " + index);
                     this.args[index] = (String)orderInput.get(i);
                     index++;
                 }
             }
         }


        return isValid;
    }

}
