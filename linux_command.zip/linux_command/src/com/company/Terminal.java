package com.company;

import java.io.BufferedReader;
import java.io.BufferedWriter;
//import java.io.Closeable;
import java.io.File;
//import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
//import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Terminal {

    /*
    public String Path = System.getProperty("user.dir");
    File file;
    public String mkdir(String sourcePath) {
        int ind = sourcePath.lastIndexOf("\\");
        String filename = "";
        if (ind == -1) {
            filename = sourcePath;
            sourcePath = this.Path;
        } else {
            filename = sourcePath.substring(ind + 1, sourcePath.length());
            sourcePath = sourcePath.substring(0, ind);
        }

        File checkFile = new File(sourcePath);
        if (checkFile.exists() && checkFile.isDirectory()) {
            checkFile = new File(sourcePath + "\\" + filename);
            if (checkFile.exists()) {
                return "This Directory is already exist";
            } else {
                checkFile.mkdir();
                return "This Directory is added";
            }
        } else {
            return "This Directory is not found to create directory in it";
        }
    }
    */

    public String mkdir(String dirSourth) {
        System.out.println("Dir = " + dirSourth);
        //mkdir & rmdir
        File file = new File(dirSourth);
        if (file.mkdir()) {
            return ("Done");
        } else
            return ("False");
        //file.delete(); // delete dir


    }

    public void rmdir(String dirSourth) {
        System.out.println("Dir = " + dirSourth);
        //mkdir & rmdir
        File file = new File(dirSourth);

        file.delete(); // delete dir


    }

    public String echo(String word){
        return word;
    }

    public String cat (String path){
        //Scanner input = new Scanner(System.in);
        String line = null;
        //String t = "C:\\Users\\win10\\Downloads\\Documents\\dirc\\eee.txt" ;
        String data = "";
        try
        {
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferReader = new BufferedReader(fileReader);
            while ((line = bufferReader.readLine()) != null)
            {  data += line;}
            bufferReader.close();
        }
        catch(IOException ex)
        {
            System.out.println("Error");
        }
        return  data;

    }


    public static void Date()
    {
	    /*Scanner obj = new Scanner(System.in);
		System.out.println("Enter Command");
		String obj1 = obj.nextLine();
		//System.out.println(obj1);*/

        LocalDate date = LocalDate.now();
        System.out.println(date);
    }

    public static void Clear()
    {
        for(int i = 0; i <= 6; i++)
        {
            System.out.printf("\n");
        }
    }

    public static void ls() throws IOException
    {

        String directory = System.getProperty("user.dir");

        File folder = new File(directory);
        File[] lists = folder.listFiles();
        for(int i = 0; i < lists.length; i++)
        {

            if(lists[i].isFile())
            {
                System.out.println(lists[i]);
            }
        }
    }

    public static void rm(String sourcePath)
    {
		/*file = new Scanner(System.in);
		String Name = file.nextLine();*/
        //System.setProperty("user.dir", sourcePath);
        Path file1 = Paths.get(sourcePath);
        if(Files.exists(file1))
        {
            try
            {
                Files.delete(file1);
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        else
        {
            System.out.println("File does not exist");
        }


    }



    public static void pwd()
    {
        String directory = System.getProperty("user.dir");
        System.out.println(directory);
    }

    public static void cd(String destination)
    {

        System.setProperty("user.dir", destination);

	    /*
	     * String Path;
	     * File file;
	     if(sourcePath.equals(""))
	     {
    		Path = System.getProperty("user.dir") ;
    		file = new File(Path);
    		System.out.println("Current directory: ");
    		pwd();*/
        //System.out.println("Current directory: " + file1);
    }



    public static String cp(String sourcePath,String destinatuinPath) throws IOException
    {

        String Path=System.getProperty("user.dir");
        File file=new File(Path);
        int ind=sourcePath.lastIndexOf("\\");
        String filename="";

        if(ind==-1) {
            filename=sourcePath;
            sourcePath=Path;
        }
        else {
            filename=sourcePath.substring(ind+1, sourcePath.length());
            sourcePath=sourcePath.substring(0,ind);
        }

        String checkPath=sourcePath;
        File checkFile=new File(checkPath);
        if(checkFile.exists() && checkFile.isDirectory()) {

            checkFile=new File(sourcePath+"\\"+filename);

            if(checkFile.exists() && !checkFile.isDirectory()) {
                int ind2=destinatuinPath.lastIndexOf("\\");
                String filename2="";

                if(ind2==-1) {
                    filename2=destinatuinPath;
                    destinatuinPath=Path;
                }
                else {
                    filename2=destinatuinPath.substring(ind2+1, destinatuinPath.length());
                    destinatuinPath=destinatuinPath.substring(0,ind2);
                }

                String checkPath2=destinatuinPath;
                File checkFile2=new File(checkPath2);

                if(checkFile2.exists() && checkFile2.isDirectory()) {
                    checkFile2=new File(destinatuinPath+"\\"+filename2);
                    if(checkFile2.exists() && !checkFile2.isDirectory()) {
                        return "sorry file2 is already exist";
                    }
                    else
                    {
                        if(checkFile2.isDirectory())
                        {
                            checkFile2 = new File(destinatuinPath + "\\" + filename2 +"\\"+filename);
                            if(checkFile2.exists())
                            {
                                return "sorry file2 is already exist";
                            }
                        }
                        Files.copy(checkFile.toPath(), checkFile2.toPath());
                        return "Copied succedfully";
                    }
                }
                else
                {
                    return "This Second Directory is not found";
                }
            }
            else {
                return "This file is not found";
            }
        }
        else {
            return "This Directory is not found";
        }
    }


    public static String mv(String sourcePath, String destinationPath)
    {
        String Path=System.getProperty("user.dir");
        File file=new File(Path);
        int ind=sourcePath.lastIndexOf("\\");
        String filename="";

        if(ind==-1) {
            filename=sourcePath;
            sourcePath=Path;
        }
        else {
            filename=sourcePath.substring(ind+1, sourcePath.length());
            sourcePath=sourcePath.substring(0,ind);
        }

        String checkPath=sourcePath;
        File checkFile=new File(checkPath);
        if(checkFile.exists() && checkFile.isDirectory()) {

            checkFile=new File(sourcePath+"\\"+filename);

            if(checkFile.exists() && !checkFile.isDirectory()) {
                int ind2=destinationPath.lastIndexOf("\\");
                String filename2="";

                if(ind2==-1) {
                    filename2=destinationPath;
                    destinationPath=Path;
                }
                else {
                    filename2=destinationPath.substring(ind2+1, destinationPath.length());
                    destinationPath=destinationPath.substring(0,ind2);
                }

                String checkPath2=destinationPath;
                File checkFile2=new File(checkPath2);

                if(checkFile2.exists() && checkFile2.isDirectory()) {
                    checkFile2=new File(destinationPath+"\\"+filename2);
                    if(checkFile2.exists() && !checkFile2.isDirectory()) {
                        return "sorry file2 is already exist";
                    }
                    else {
                        if(checkFile2.isDirectory()) {
                            checkFile2 = new File(destinationPath + "\\" + filename2 +"\\"+filename);
                            if(checkFile2.exists()) {
                                return "sorry file2 is already exist";
                            }
                        }

                        try
                        {
                            Files.move(checkFile.toPath(), checkFile2.toPath());
                        }
                        catch (IOException e)
                        {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }

                        return "Moved succedfully";
                    }
                }
                else
                {
                    return "This Second Directory is not found";
                }
            }
            else
            {
                return "This file is not found";
            }
        }
        else
        {
            return "This Directory is not found";
        }

    }

    public static void help()
    {
        Scanner s = new Scanner(System.in);
        String sr = s.nextLine();
        if(sr.equals("."))
        {
            String result = "";
            ArrayList<String>Commands = new ArrayList<>();
            Commands.add("pwd\t print the current working directory");
            Commands.add("ls\t list files' names in the current Directory");
            Commands.add("cd\t change the current ddirectory to another one");
            Commands.add("mkdir\t make new directory in a given path");
            Commands.add("rmdir\t remove a given directory ");
            Commands.add("rm\t remove specific file");
            Commands.add("mv\t Moves one or more file from one directory to another");
            Commands.add("clear\t clear the current terminal screen");
            Commands.add("more\t dispaly and scroll down the output");
            Commands.add("cp\t copy item from specific path to other path");
            Commands.add("cat\t in case 1 args it's dispaly the content of the file, in case of 2 args it's concatinate them ");
            Commands.add("date\t display the current date and time ");
            Commands.add("args\t list all parameters on the command line");
            Commands.add("help\t Provides Help information for commands");
            Commands.add("exit\t Quits the CMD.EXE program (command interpreter).");

            for(int i = 0; i < Commands.size(); i++)
            {
                result += Commands.get(i);
                result += "\n";
            }
            System.out.println(result);

        }
        else
        {
            HashMap<String, String> Commands = new HashMap<String, String>();
            Commands.put("pwd", "pwd\t print the current working directory");
            Commands.put("args", "args\t list all parameters on the command line");
            Commands.put("ls", "ls\t list files' names in the current Directory");
            Commands.put("rm", "rm\t remove specific file");
            Commands.put("mv", "mv\t Moves one or more file from one directory to another");
            Commands.put("clear", "clear\t clear the current terminal screen\"");
            Commands.put("cd", "cd\t change the current ddirectory to another one");
            Commands.put("help", "help\t Provides Help information for commands");
            Commands.put("cp", "cp\t copy item from specific path to other path");
            Commands.put("more", "more\t dispaly and scroll down the output");
            Commands.put("cat", "cat\t in case 1 args it displays the content of the file, in case of 2 args it's concatinate them");
            Commands.put("date", "date\t display the current date and time");
            Commands.put("exit", "exit\t Stop all");
            Commands.put("rmdir", "rmdir\t remove a given directory");
            Commands.put("mkdir", "mkdir\t make new directory in a given path");

            for(String i : Commands.keySet())
            {
                if(sr.equals(i))
                {
                    System.out.println(Commands.get(i));
                }
            }

        }


    }



    public static void args()
    {
        Scanner s = new Scanner(System.in);
        String sr = s.nextLine();
        if(sr.equals("."))
        {
            String result = "";
            ArrayList<String> Command = new ArrayList<>();
            Command.add("pwd\t takes 0 args");
            Command.add("ls\t takes 0 args");
            Command.add("cd\t takes 1 args: Path");
            Command.add("mkdir\t takes 1 args: Path");
            Command.add("rmdir\t takes 1 args");
            Command.add("rm\t takes 1 args sourcePath");
            Command.add("mv\t takes 2 args: sourcePath , destinatuinPath");
            Command.add("clear\t takes 0 args");
            Command.add("more\t takes 0 args");
            Command.add("cp\t takes 2 args : sourcePath , destinatuinPath");
            Command.add("cat\t takes 1 or 2 args");
            Command.add("date\t takes 0 args");
            Command.add("args\t takes 0 args");
            Command.add("help\t takes 0 args");
            Command.add("exit\t takes 0 args");

            for(int i = 0 ;i< Command.size() ;i++)
            {
                result += Command.get(i);
                result += "\n";
            }
            System.out.println(result);
        }

        else
        {
            HashMap<String, String> Commands = new HashMap<String, String>();
            Commands.put("pwd", "pwd\t takes 0 args");
            Commands.put("args", "args\t takes 0 args");
            Commands.put("ls", "ls\t takes 0 args");
            Commands.put("rm", "rm\t takes 1 arg, sourth path");
            Commands.put("mv", "mv\t takes 2 args, sourth path and destination path");
            Commands.put("clear", "clear\t takes 0 args\"");
            Commands.put("cd", "cd\t takes 1 arg, destination path");
            Commands.put("help", "help\t takes 0 args");
            Commands.put("cp", "cp\t takes 2 args, sourth path and destination path");
            Commands.put("more", "more\t takes 0 args");
            Commands.put("cat", "cat\t takes 1 or 2 args");
            Commands.put("date", "date\t takes 0 args");
            Commands.put("exit", "exit\t takes 0 args");
            Commands.put("rmdir", "rmdir\t takes 1 arg");
            Commands.put("mkdir", "mkdir\t takes 1 arg, path");

            for(String i : Commands.keySet())
            {
                if(sr.equals(i))
                {
                    System.out.println(Commands.get(i));
                }
            }
        }

    }


    public static void more (String SourcePath) {
        File check=new File(SourcePath);
        String Path=System.getProperty("user.dir");
        File file=new File(Path);
        if(check.exists()==false)
        {
            //System.out.println("DD");
            Path = Path+"\\"+SourcePath;
            check=new File(Path+"\\"+SourcePath);
            if(check.exists()==false)
            {
                System.out.println("The system cannot find the path specified.");
            }
        }

        if(check.isDirectory())
        {
            System.out.println("Faild to get the file beacuse it is directory");
        }

        ArrayList<String> Lines=new ArrayList<>();
        try (BufferedReader buff = Files.newBufferedReader(Paths.get(SourcePath)))
        {
            String line;
            while ((line = buff.readLine()) != null)
            {
                Lines.add(line);
            }

        }

        catch (IOException e)
        {
//	        e.printStackTrace();
            System.err.format("IOException: %s%n", e);
        }


        Scanner input = new Scanner(System.in);
        for(int i = 0; i <= Lines.size()-1; i+=5)
        {
            while(i != Lines.size()-1)
            {
                for(int j = i; j < i+5; j++)
                {
                    //System.out.println("Sg");
                    System.out.println(Lines.get(j));
                }
                System.out.println("Press 1 for next 5 lines, 2 to stop: ");
                String in = input.nextLine();
                if(in.equals("1"))
                {
                    break;
                }
                else
                {
                    return;
                }
            }
        }
    }

    public static void exit()
    {
        System.exit(0);
    }
}

