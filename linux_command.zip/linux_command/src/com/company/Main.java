package com.company;
//rmdir C:\\Users\\win10\\Downloads\\direct
import java.io.*;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) throws IOException {
	// write your code here
        Scanner in = new Scanner(System.in);
        Terminal terminal = new Terminal();
        Scanner source;
        Scanner destination;
        String Path = System.getProperty("user.dir");
        //System.out.println("path = " + Path);
        while(true){

            System.out.println(Path);
            String orders = in.nextLine(); //receive orders from user Between each order "|"
            String [] order = orders.split("\\|"); //split each order into index in array
            String output = ""; //  Result of the command
            Parser parser = new Parser();
            for (int i = 0; i < order.length; i++) { //one order

                boolean isValid = parser.parse(order[i]);

                if (!isValid) {
                    System.out.println("command not Valid");
                } else {

                    if (parser.cmd.equals("mkdir")) {
                        System.out.println("arg0 = " + parser.args[0]);
                        output = terminal.mkdir(parser.args[0]);
                        //System.out.println(output);
                    } else if (parser.cmd.equals("rmdir")) {
                        terminal.rmdir(parser.args[0]);
                    } else if (parser.cmd.equals("echo")) {
                        output = terminal.echo(parser.args[0]);
                        //System.out.println(output);
                    } else if (parser.cmd.equals("cat")) {
                        output = terminal.cat(parser.args[0]);
                        //System.out.println(output);
                    }
                    else if(parser.cmd.equals("date"))
                    {
                        terminal.Date();
                    }

                    if(parser.cmd.equals("clear"))
                    {
                        terminal.Clear();
                    }

                    if(parser.cmd.equals("ls"))
                    {
                        terminal.ls();
                    }

                    if(parser.cmd.equals("rm"))
                    {
                        source = new Scanner(System.in);
                        String sr = source.nextLine();
                        terminal.rm(sr);
                    }

                    if(parser.cmd.equals("pwd"))
                    {
                        terminal.pwd();
                    }

                    if(parser.cmd.equals("help"))
                    {
                        terminal.help();
                    }

                    if(parser.cmd.equals("cd"))
                    {
                        source = new Scanner(System.in);
                        String sr = source.nextLine();
                        terminal.cd(sr);
                    }

                    if(parser.cmd.equals("cp"))
                    {
                        destination = new Scanner(System.in);
                        String st = destination.nextLine();
                        source = new Scanner(System.in);
                        String sr = source.nextLine();
                        terminal.cp(st,sr);
                    }

                    if(parser.cmd.equals("mv"))
                    {
                        destination = new Scanner(System.in);
                        String st = destination.nextLine();
                        source = new Scanner(System.in);
                        String sr = source.nextLine();
                        terminal.mv(st,sr);
                    }

                    if(parser.cmd.equals("args"))
                    {
                        terminal.args();
                    }

                    if(parser.cmd.equals("help"))
                    {
                        terminal.help();
                    }

                    if(parser.cmd.equals("more"))
                    {
                        source = new Scanner(System.in);
                        String sr = source.nextLine();
                        terminal.more(sr);
                    }

                    if(parser.cmd.equals("exit"))
                    {
                        terminal.exit();
                    }
                }
            }
                if (parser.RedirectingResult.equals(""))
                    System.out.println(output);
                else {
                    if(parser.operator.equals(">")) {

                        /**
                         String line = null;
                         try
                         {
                         FileReader fileReader = new FileReader(parser.redirectingFile);
                         BufferedReader bufferReader = new BufferedReader(fileReader);
                         while ((line = bufferReader.readLine()) != null)
                         {  System.out.println(line);}
                         bufferReader.close();
                         }
                         catch(IOException ex)
                         {
                         System.out.println("Error");
                         }
                         */

                        // overload  file
                        File file = new File(parser.RedirectingResult);
                        PrintWriter out = new PrintWriter(file);

                        for (int j = 0; j < output.length(); ++j) {
                            if (output.charAt(j) == '\n') {
                                out.println();
                            } else {
                                out.print(output.charAt(j));
                            }
                        }

                        out.close();

                    }

                    // append to file
                    else if (parser.operator.equals(">>")) {
                        System.out.println("in");
                        System.out.println("redi = " + parser.RedirectingResult);
                        File file = new File(parser.RedirectingResult);
                        FileWriter fr = new FileWriter(file, true);
                        BufferedWriter br = new BufferedWriter(fr);
                        PrintWriter pr = new PrintWriter(br);
                        pr.println(output);
                        pr.close();
                        br.close();
                        fr.close();
                    }

                }


        }
    }
}
