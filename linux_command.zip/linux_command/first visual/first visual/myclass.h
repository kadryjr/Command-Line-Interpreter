#pragma once
#include <iostream>
#include <fstream>
using namespace std;

int main{
	std::cout << 
}


